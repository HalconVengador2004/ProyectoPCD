package com.mycompany.proyecto_grupo_cliente_servidor;

public class Jugador {


    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
